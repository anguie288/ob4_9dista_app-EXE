//
//  SceneDelegate.h
//  ob4_9dista_app
//
//  Created by Angela on 2020-04-23.
//  Copyright © 2020 angela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

