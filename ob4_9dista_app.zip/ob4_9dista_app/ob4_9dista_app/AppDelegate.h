//
//  AppDelegate.h
//  ob4_9dista_app
//
//  Created by Angela on 2020-04-23.
//  Copyright © 2020 angela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

