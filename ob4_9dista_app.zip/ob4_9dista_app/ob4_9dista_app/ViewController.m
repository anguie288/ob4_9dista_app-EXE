//
//  ViewController.m
//  ob4_9dista_app
//
//  Created by Angela on 2020-04-23.
//  Copyright © 2020 angela. All rights reserved.
//

#import "ViewController.h"
#import "DistanceGetter/DGDistanceRequest.h"

@interface ViewController ()

@property (nonatomic) DGDistanceRequest *req;


@property (weak, nonatomic) IBOutlet UITextField *starlo;


@property (weak, nonatomic) IBOutlet UITextField *loca_a;

@property (weak, nonatomic) IBOutlet UITextField *loca_b;

@property (weak, nonatomic) IBOutlet UITextField *loca_c;



@property (weak, nonatomic) IBOutlet UILabel *dis_a;

@property (weak, nonatomic) IBOutlet UILabel *dis_b;

@property (weak, nonatomic) IBOutlet UILabel *dis_c;


@property (weak, nonatomic) IBOutlet UIButton *calcu_button;


@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;

@end

@implementation ViewController


// button functionality
- (IBAction)calcu_button_func:(id)sender {
    
    
    self.calcu_button.enabled = NO;
    
    self.req = [DGDistanceRequest alloc];
    
    NSString *start = self.starlo.text;
    
    NSString *desta = self.loca_a.text;
    
    NSString *destb = self.loca_b.text;
    
    NSString *destc = self.loca_c.text;
    
    NSArray * dests = @[desta, destb, destc];
    
    
    // req start
    self.req = [self.req initWithLocationDescriptions: dests sourceDescription: start];
    
    
    __weak ViewController *weakself = self;
    
    // req callback
    self.req.callback = ^void (NSArray *responses){
        
        ViewController *strongself = weakself;
        if(!strongself) { return; }
        
        
        NSNull *badr1 = [NSNull null];
        NSNull *badr2 = [NSNull null];
        NSNull *badr3 = [NSNull null];
        
        if(badr1 != responses[0]) {
            double num1;
            
            if(strongself.segment.selectedSegmentIndex == 0) {
            
            num1= ([responses[0] floatValue]/1000.0);
            NSString *knum1 = [NSString stringWithFormat: @"%.2f km", num1];
            strongself.dis_a.text = knum1;
            }
            
            else if (strongself.segment.selectedSegmentIndex == 1){
               
                num1= ([responses[0] floatValue]/1.0);
                NSString *mnum1 = [NSString stringWithFormat: @"%.2f mts", num1];
                strongself.dis_a.text = mnum1;
                
            }
            
        } else {
            strongself.dis_a.text = @"error"; }
        
        
        if(badr2 != responses[1]) {
            double num2 = ([responses[1] floatValue]/1000.0);
            NSString *knum2 = [NSString stringWithFormat: @"%.2f km", num2];
            strongself.dis_b.text = knum2;
        } else {
            strongself.dis_b.text = @"error";
        }
        
        
        
        if(badr3 != responses[2]) {
            double num3 = ([responses[2] floatValue]/1000.0);
            NSString *knum3 = [NSString stringWithFormat: @"%.2f km", num3];
            strongself.dis_c.text = knum3;
        } else {
            strongself.dis_c.text = @"error";
        }
        
        
        strongself.req = nil;
        strongself.calcu_button.enabled = YES;
        
    };
    
    
    [self.req start]; 
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
}


@end
